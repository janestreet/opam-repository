module Findlib = struct
  module Config = Config
  module Rule = Rule
  module Rules = Rules
  module Vars = Vars
  module Meta = Meta
  module Package = Package0
end
