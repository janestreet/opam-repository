module Digest = Dune_digest
module Restore_result = Dune_cache_storage.Restore_result
module Store_result = Dune_cache_storage.Store_result
