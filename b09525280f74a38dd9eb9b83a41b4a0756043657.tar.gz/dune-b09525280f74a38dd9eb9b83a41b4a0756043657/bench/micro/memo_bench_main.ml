Inline_benchmarks_public.Runner.main ~libname:"memo_bench"
