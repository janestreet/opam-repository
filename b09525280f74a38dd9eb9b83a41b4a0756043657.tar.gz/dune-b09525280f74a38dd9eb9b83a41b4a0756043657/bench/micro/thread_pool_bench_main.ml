Inline_benchmarks_public.Runner.main ~libname:"thread_pool_bench"
