Inline_benchmarks_public.Runner.main ~libname:"digest_bench"
