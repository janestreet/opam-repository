Inline_benchmarks_public.Runner.main ~libname:"fiber_bench"
