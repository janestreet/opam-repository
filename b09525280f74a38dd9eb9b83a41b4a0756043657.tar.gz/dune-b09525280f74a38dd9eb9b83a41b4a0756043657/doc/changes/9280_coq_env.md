- Add `coqdoc_flags` field to `coq` field of `env` stanza allowing the setting of
  workspace-wide defaults for `coqdoc_flags`. (#9280, fixes #9139, @Alizter)