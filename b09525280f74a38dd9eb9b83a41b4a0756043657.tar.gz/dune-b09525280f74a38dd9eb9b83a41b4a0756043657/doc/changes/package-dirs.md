- Mark installed directories in `dune-package` files. This fixes `(package)`
  dependencies against packages that contain such directories. (#8953, fixes
  #8915, @emillon)
