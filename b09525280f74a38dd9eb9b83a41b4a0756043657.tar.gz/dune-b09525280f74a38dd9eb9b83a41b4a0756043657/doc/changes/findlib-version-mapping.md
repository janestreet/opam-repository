- dune-build-info: when `version=""` is found in a `META` file, we now return
  `None` as a version string (#9177, @emillon)
