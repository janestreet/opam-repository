A paper describing the Memo library presented at the OCaml Users and
Developers Workshop 2022.

To render a PDF version, run `pandoc memo.md --citeproc -H header.tex -o memo.pdf`.
