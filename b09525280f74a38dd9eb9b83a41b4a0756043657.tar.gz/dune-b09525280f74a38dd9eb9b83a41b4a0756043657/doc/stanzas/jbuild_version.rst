jbuild_version
--------------

Deprecated. This `jbuild_version` stanza is no longer used and will be removed
in the future.
