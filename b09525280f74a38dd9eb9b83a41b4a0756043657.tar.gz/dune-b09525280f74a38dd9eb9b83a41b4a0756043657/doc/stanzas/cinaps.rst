cinaps
------

A ``cinaps`` stanza is available to support the ``cinaps`` tool.  See the
`cinaps website <https://github.com/janestreet/cinaps>`_ for more details.
