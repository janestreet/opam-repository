coq.theory
----------

See the documentation on the :ref:`coq-theory`, :ref:`coq-extraction`,
:ref:`coq-pp`, and related stanzas.
