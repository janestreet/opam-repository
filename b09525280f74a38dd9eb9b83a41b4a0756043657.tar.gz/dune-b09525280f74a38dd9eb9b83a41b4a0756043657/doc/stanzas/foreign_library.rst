.. _foreign_library:

foreign_library
---------------

The ``foreign_library`` stanza describes archives of separately compiled foreign
object files that can be packaged with an OCaml library or linked into an OCaml
executable. See :doc:`reference/foreign` for further details and examples.
