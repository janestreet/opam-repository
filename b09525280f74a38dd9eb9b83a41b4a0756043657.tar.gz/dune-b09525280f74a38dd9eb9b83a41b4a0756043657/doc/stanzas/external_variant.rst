external_variant
-----------------

This stanza was experimental and removed in Dune 2.6. See :ref:`dune-variants`.
