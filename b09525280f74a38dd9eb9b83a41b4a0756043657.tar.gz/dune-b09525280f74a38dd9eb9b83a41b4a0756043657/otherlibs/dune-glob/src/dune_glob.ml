(** Simple glob support library. *)

module V1 = Glob
